import { SideNavItems, SideNavSection } from '@modules/navigation/models';

export const sideNavSections: SideNavSection[] = [
    {
        text: 'Admin Panel',
        items: ['dashboard'],
    },
];

export const sideNavItems: SideNavItems = {
    dashboard: {
        icon: 'tachometer-alt',
        text: 'Dashboard',
        link: '/dashboard',
    },
    
    
    tables: {
        icon: 'table',
        text: 'Tables',
        link: '/tables',
    },
};

import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup, FormControl, Validators } from '@angular/forms';
import {Router,ActivatedRoute} from "@angular/router";
import { AppCommonService} from '../../../app-common/services/app-common.service';

@Component({
    selector: 'sb-login',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './login.component.html',
    styleUrls: ['login.component.scss'],
})
export class LoginComponent implements OnInit {
    loginForm : FormGroup;
    returnUrl: string;
    submitted: boolean = false;
    password:string;

    constructor(private fb:FormBuilder, private route: ActivatedRoute, public commonService:AppCommonService, private router: Router) {}
    ngOnInit() {
        this.loginForm = this.fb.group({
            email:['',Validators.required],
            password:['',Validators.required]
            });
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    }
    onSubmit(){
        this.submitted = true;
          if(this.loginForm.invalid){
              return false;
          }
          if(this.loginForm.controls.email.value && this.loginForm.controls.password.value){
            this.password = this.loginForm.controls.password.value;
            this.commonService.post('login',{
                "email": this.loginForm.controls.email.value,
                "password": this.loginForm.controls.password.value
            })
            .subscribe(res => {
                let result:any = res;
                if(result.token){
                    localStorage.setItem('isLoggedin', '1');
                    localStorage.setItem('tokenDetails',result.token);
                    this.router.navigateByUrl('blank', {skipLocationChange: true}).then(()=>
                    this.router.navigate([this.returnUrl]));
                }
                else{
                    this.commonService.openSnackBar('Invalid email or password','error');
                }
            });
          }
      }

}

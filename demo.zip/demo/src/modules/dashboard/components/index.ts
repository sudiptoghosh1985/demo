import { DashboardTablesComponent } from './dashboard-tables/dashboard-tables.component';

export const components = [
    DashboardTablesComponent,
];
export * from './dashboard-tables/dashboard-tables.component';

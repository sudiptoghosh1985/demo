import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder,FormGroup, FormControl, Validators } from '@angular/forms';
import { AppCommonService} from '../../../app-common/services/app-common.service';

@Component({
  selector: 'sb-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss']
})
export class EditComponent implements OnInit {
  userForm : FormGroup;
  submitted: boolean = false;
  @Input() editUserID: number;
  @Input() editUser: boolean;
  @Output() showEvent = new EventEmitter<string>();
  showEdit:boolean = false;

  constructor(private fb:FormBuilder, public commonService:AppCommonService) { }

  ngOnInit(): void {
    this.userForm = this.fb.group({
      first_name:['',Validators.required],
      last_name:['',Validators.required],
      avatar:['',Validators.required],
      email:['',Validators.required]
      });

    if(this.editUser){
      this.showEdit= true;
      this.commonService.get('users/'+this.editUserID).subscribe(res=>{
        let result:any = res;
        this.userForm.patchValue({
            "first_name": result.data.first_name,
            "last_name": result.data.last_name,
            "email": result.data.email,
            "avatar":result.data.avatar
        });
      });
    
    }
  }
  onEdit(){
    this.submitted = true;
      if(this.userForm.invalid){
          return false;
      }
      if(this.userForm.controls.first_name.value && this.userForm.controls.last_name.value && this.userForm.controls.email.value){
        this.commonService.put('users',{
          "first_name": this.userForm.controls.first_name.value,
          "last_name": this.userForm.controls.last_name.value,
          "email":this.userForm.controls.email.value,
          "avatar":this.userForm.controls.avatar.value,
      }).subscribe(res=>{
          this.commonService.openSnackBar('User has been edited successfuly','Success');
          this.showEvent.emit(this.editUser); 
      });
      }
    }
  onSubmit(){
    this.submitted = true;
      if(this.userForm.invalid){
          return false;
      }
      if(this.userForm.controls.first_name.value && this.userForm.controls.last_name.value && this.userForm.controls.email.value){
        this.commonService.post('users',{
          "first_name": this.userForm.controls.first_name.value,
          "last_name": this.userForm.controls.last_name.value,
          "email":this.userForm.controls.email.value,
          "avatar":this.userForm.controls.avatar.value,
      }).subscribe(res=>{
          this.userForm.reset();
          this.commonService.openSnackBar('User has been added successfuly','Success');
      });
      }
    }
}

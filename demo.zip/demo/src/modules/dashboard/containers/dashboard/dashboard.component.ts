import { ChangeDetectionStrategy, Component, OnInit,ViewChild } from '@angular/core';
import { AppCommonService } from '../../../app-common/services/app-common.service';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';

@Component({
    selector: 'sb-dashboard',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './dashboard.component.html',
    styleUrls: ['dashboard.component.scss'],
})

export class DashboardComponent implements OnInit {
    @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
    displayedColumns: string[] ;
    users:any;
    dataSource:any;
    totalData:any;
    pageIndex:number = 0;
    pageLimit:any;
    selectTab:number = 0;
    editUser:boolean = false;
    editUserID:number = 0;
    constructor( public commonService:AppCommonService) {}
    ngOnInit() {
        this.getUsers();
    }
    getUsers(){
        this.commonService.get('users?page='+this.pageIndex).subscribe(res=>{
            this.users = res;
            this.displayedColumns = Object.keys(this.users.data[0]);
            this.displayedColumns.push('Action');
            this.dataSource = new MatTableDataSource(this.users.data);
            this.dataSource.paginator = this.paginator;
            this.pageLimit = this.users.total_pages;
            this.totalData = this.users.total;
        });
    }
    changePage(pageNo:any){
        console.log(pageNo)
        this.pageIndex = pageNo.pageIndex;
        this.getUsers();
    }
    delete(data:number){
        this.commonService.delete('users/'+data).subscribe(res=>{
            this.commonService.openSnackBar('User has been deleted successfully','Success');
        });
    }
    edit(id:number){
        this.editUser = true;
        this.editUserID = id;
        this.selectTab = 1;
    }
    receiveEvent(data:boolean){
        this.editUser = false;
        this.selectTab = 0;
        this.editUserID = 0;
    }
}


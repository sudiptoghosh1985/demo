import { DashboardComponent } from './dashboard/dashboard.component';

export const containers = [DashboardComponent];

export * from './dashboard/dashboard.component';

import { Injectable } from '@angular/core';
import { CanActivate,Router,ActivatedRouteSnapshot,RouterStateSnapshot } from '@angular/router';
import { Observable,of } from 'rxjs';

@Injectable()
export class DashboardGuard implements CanActivate {
    constructor(private router: Router) {
    
    }
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):Observable<boolean> {
        if (localStorage.getItem('isLoggedin')) {
            return of(true);
        }
        else{
            this.router.navigate(['/auth/login'], { queryParams: { returnUrl: state.url }});
            return of(false);
        }
    }
}

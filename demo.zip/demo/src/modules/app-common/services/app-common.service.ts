import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import {MatSnackBar} from '@angular/material/snack-bar';
@Injectable({
    providedIn: 'root'
  })
export class AppCommonService {
    constructor(private http:HttpClient, public _snackBar: MatSnackBar) {}
    baseUrl:any = "https://reqres.in/api/";

    post(url:any, body:any){
        return this.http.post(this.baseUrl+url, body);
    }
    get(url:any){
       return  this.http.get(this.baseUrl+url);
    }
    delete(url:any){
       return this.http.delete(this.baseUrl+url);
    }
    put(url:any, body:any){
        return this.http.put(this.baseUrl+url, body);
    }
    openSnackBar(message: string, action: string) {
        this._snackBar.open(message, action, {
          duration: 2000,
        });
    }
    logout(){
        localStorage.clear();
        localStorage.setItem('isLoggedin', '0');
    }
}
